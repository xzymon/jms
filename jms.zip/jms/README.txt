Projekt z dwoma modulami. To okrojona wersja tego na czym sobie pracowalem, ale zawiera to co jest istotne.

Jezeli projekt na IDEA bedzie mial jakies problemy z buildem, mozna go zbudowac, posiadajac zainstalowanego gradle
1. Budujemy ejb
	w katalogu ejb odpalamy:
		gradle jar
2. Budujemy ear
	w katalogu ear odpalamy:
		gradle ear

Sam kod podlegajacy budowaniu zawiera kilka klas, ale tak naprawde prawdziwie istotna jest tylko klasa UniversalMessagingListener.

W katalogu resources sa tez dwa deskryptory istotne dla wdrozenia - standardowy (ejb-jar.xml) i jboss'owy (jboss-ejb3.xml).

Samo skompilowanie klas i zbudowanie EARa nie wystarczy by aplikacja byla "pelna". Potrzebne jest jeszcze archiwum resource adaptera, oraz modyfikacja pliku wdrozeniowego.
	Plik wdrozeniowy w EAR w META-INF/application.xml nalezy wzbogacic info o pliku resource adaptera : umra.rar . To plik adaptera dla Universal Messagingu (Universal Messaging Resource Adapter).

Aby ulatwic zorientowanie sie jak docelowo to powinno wygladac, warto zajzec do katalogu ear/build/libs . Sa tam zawarte 2 dodatkowe katalogi, o samo-opisujacych-sie nazwach - jeden zawiera rozpakowane archiwum EAR z juz dodanym umra.rar oraz ze zmodyfikowanym deskryptorem application.xml; drugie zawiera to wszystko spakowane do EARa.

W umra.rar sa JARy potrzebne adapterowi oraz pliki konfiguracyjne. Plik ra.xml jest dostarczony przez providera. Plik ironjacamar.xml to moja radosna tworczosc i to tam bym sie dopatrywal koniecznosci dodania/usuniecia czegokolwiek.

Pare linkow ktore wydaja mi sie byc uzyteczne sposrod masy dokumentacji ktore przejzalem:
	1. Projekt ilustrujacy podlaczanie sie do UniversalMessaging przez JMS:
		https://github.com/SoftwareAG/j2ee_messaging_apps

	2. Dokumentacja Universal Messaging - opis parametrow dla Resource Adaptera
		https://documentation.softwareag.com/onlinehelp/Rohan/num10-5/10-5_UM_webhelp/index.html#page/um-webhelp%2Fco-jms_jboss_resource_adapter.html%23

	3. Dokumentacja JBossa
		https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.2/html/configuring_messaging/resource_adapters#deploy_configure_generic_jms_resource_adapter
